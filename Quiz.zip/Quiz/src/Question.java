
public class Question {
	String question;
	String answer;

	public Question(String question, String answer) {
		super();
		this.question = question;
		this.answer = answer;
	}
}
